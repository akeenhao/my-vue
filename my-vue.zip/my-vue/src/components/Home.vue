<template>
  <div>
    <div id="myChart" ref="myChartRef" :style="{width: '600px', height: '300px'}">
    </div>
    <el-button type="success" @click="this.queryData">重置</el-button>
  </div>
</template>

<script>
  import axios from 'axios';

  axios.defaults.baseURL = '/api'

  export default {
    name: 'home',     // 组件可以有自己的名字。

    data() {         // 组件的data必须是函数
      return {
        msg: '这里是Home视图',
        chartData: [],
        chartXaxisData: []
      }
    }, mounted() {
      // this.queryData();
      this.queryData();

    },
    methods: {
      reset() {
        this.queryData();
      },
      queryData() {
        axios.get('/queryData')
          .then(response => {
            console.log("response:" + response.data);
            this.chartData = response.data;
            axios.get('/queryCols')
              .then(response => {
                console.log("response:" + response.data);
                this.chartXaxisData = response.data;
                this.drawLine();
              })
              .catch(function (error) {
                console.log(error);
              })
          })
          .catch(function (error) {
            console.log(error);
          })
      },
      drawLine() {
        // 基于准备好的dom，初始化echarts实例
        // let myChart = this.$echarts.init(document.getElementById('myChart'))
        let myChart = this.$echarts.init(this.$refs.myChartRef);
        // 绘制图表
        myChart.setOption({
          title: {text: '浩浩超市销量图'},
          tooltip: {},
          xAxis: {
            data: this.chartXaxisData
          },
          yAxis: {},
          series: [{
            name: '',//鼠标悬浮显示信息
            type: 'bar',
            data: this.chartData
          }]
        });
      }
    }
  }
</script>

<style scoped>
  h3 {
    background-color: #1f0125;
    color: white;
    width: 20%;
  }
</style>


